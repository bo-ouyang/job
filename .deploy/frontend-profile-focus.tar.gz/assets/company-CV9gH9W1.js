import{s as t}from"./_plugin-vue_export-helper-BlhYaYAS.js";const a={getCompanies(e){return t.get("/companies",{params:e})},getCompanyDetail(e){return t.get(`/companies/${e}`)}};export{a as c};
