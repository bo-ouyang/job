import{s as t}from"./_plugin-vue_export-helper-B_8IW8ex.js";const a={getCompanies(e){return t.get("/companies",{params:e})},getCompanyDetail(e){return t.get(`/companies/${e}`)}};export{a as c};
