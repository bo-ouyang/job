import{s as t}from"./_plugin-vue_export-helper-mte-v8YJ.js";const a={getCompanies(e){return t.get("/companies",{params:e})},getCompanyDetail(e){return t.get(`/companies/${e}`)}};export{a as c};
