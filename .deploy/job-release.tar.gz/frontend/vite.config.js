import { fileURLToPath, URL } from "node:url";
import { defineConfig } from "vite";
import vue from "@vitejs/plugin-vue";

// https://vite.dev/config/
export default defineConfig({
  plugins: [vue()],
  resolve: {
    alias: {
      "@": fileURLToPath(new URL("./src", import.meta.url)),
    },
  },
  build: {
    sourcemap: false,
    cssCodeSplit: true,
    chunkSizeWarningLimit: 1200,
    rollupOptions: {
      output: {
        manualChunks(id) {
          if (!id.includes("node_modules")) {
            return;
          }
          if (id.includes("echarts") || id.includes("zrender")) {
            return "vendor-echarts";
          }
          if (id.includes("element-plus") || id.includes("@element-plus")) {
            return "vendor-element-plus";
          }
          if (id.includes("vue") || id.includes("pinia") || id.includes("vue-router")) {
            return "vendor-vue";
          }
          return "vendor";
        },
      },
    },
  },
  server: {
    host: "0.0.0.0", // 允许局域网访问
    port: 8081, // 指定前端端口
    proxy: {
      "/api": {
        target: "http://127.0.0.1:8000", // 后端 API 地址
        changeOrigin: true,
      },
    },
  },
  test: {
    environment: "jsdom",
    globals: true,
    clearMocks: true,
  },
});
