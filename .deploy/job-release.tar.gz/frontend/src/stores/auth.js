import { defineStore } from "pinia";
import { ref, computed } from "vue";
import { authAPI } from "@/api/auth";
import router from "@/router";

const WALLET_PENDING_ORDER_KEY = "wallet_pending_order_no";

const clearWalletPendingOrders = () => {
  Object.keys(localStorage).forEach((key) => {
    if (key === WALLET_PENDING_ORDER_KEY || key.startsWith(`${WALLET_PENDING_ORDER_KEY}:`)) {
      localStorage.removeItem(key);
    }
  });
};

export const useAuthStore = defineStore("auth", () => {
  // State
  const user = ref(JSON.parse(localStorage.getItem("user")) || null);
  const token = ref(localStorage.getItem("token") || null);
  const refreshToken = ref(localStorage.getItem("refresh_token") || null);

  if (typeof window !== "undefined") {
    window.addEventListener("auth-token-refreshed", (event) => {
      token.value = event.detail?.token || localStorage.getItem("token");
    });
  }

  // Getters
  const isAuthenticated = computed(() => !!token.value);

  // Actions
  const login = async (username, password) => {
    const response = await authAPI.login(username, password);
    handleLoginSuccess(response.data);
    return response.data;
  };

  const register = async (userData) => {
    const response = await authAPI.register(userData);
    handleLoginSuccess(response.data);
    return response.data;
  };

  const loginWithPhone = async (phone, code) => {
    const response = await authAPI.loginWithPhone(phone, code);
    handleLoginSuccess(response.data);
    return response.data;
  };

  const loginWithWechat = async (code) => {
    const response = await authAPI.loginWithWechat(code);
    handleLoginSuccess(response.data);
    return response.data;
  };

  const sendSmsCode = async (phone, type = "login") => {
    const response = await authAPI.sendSmsCode(phone, type);
    return response.data;
  };

  // QR Code Login Actions
  const getQrCode = async () => {
    const response = await authAPI.getQrCode();
    return response.data;
  };

  const checkQrCodeStatus = async (ticket) => {
    const response = await authAPI.checkQrCodeStatus(ticket);
    return response.data;
  };

  const mockScanQrCode = async (ticket) => {
    return await authAPI.mockScanQrCode(ticket);
  };

  const mockConfirmQrCode = async (ticket) => {
    return await authAPI.mockConfirmQrCode(ticket);
  };

  const handleLoginSuccess = (data) => {
    // Avoid carrying AI task cache across login sessions/users.
    try {
      import("@/stores/aiTask")
        .then(({ useAiTaskStore }) => {
          const aiTaskStore = useAiTaskStore();
          if (typeof aiTaskStore.$reset === "function") {
            aiTaskStore.$reset();
          }
        })
        .catch(() => {});
    } catch (e) {
      /* ignore */
    }
    try {
      import("@/stores/agent")
        .then(({ useAgentStore }) => useAgentStore().reset())
        .catch(() => {});
    } catch (e) {
      /* ignore */
    }

    token.value = data.token.access_token;
    refreshToken.value = data.token.refresh_token;
    user.value = data.user;
    clearWalletPendingOrders();

    // Persist to localStorage
    localStorage.setItem("token", token.value);
    localStorage.setItem("refresh_token", refreshToken.value);
    localStorage.setItem("user", JSON.stringify(user.value));
  };

  const completeLogin = (data) => handleLoginSuccess(data);

  const logout = async () => {
    try {
      await authAPI.logout();
    } catch (e) {
      console.error("Logout error:", e);
    } finally {
      user.value = null;
      token.value = null;
      refreshToken.value = null;
      localStorage.removeItem("token");
      localStorage.removeItem("refresh_token");
      localStorage.removeItem("user");
      // Explicitly clear AI Task persisted state
      localStorage.removeItem("aiTask");
      clearWalletPendingOrders();
      try {
        const aiTaskStore = (await import("@/stores/aiTask")).useAiTaskStore();
        aiTaskStore.$reset();
      } catch (e) {
        console.error("Failed to reset aiTask store:", e);
      }
      try {
        const agentStore = (await import("@/stores/agent")).useAgentStore();
        agentStore.reset();
      } catch (e) {
        console.error("Failed to reset Agent store:", e);
      }
      router.push({ name: "home" });
    }
  };

  const updateProfile = async (userData) => {
    const response = await authAPI.updateProfile(userData);
    user.value = response.data;
    localStorage.setItem("user", JSON.stringify(user.value));
    return response.data;
  };

  return {
    user,
    token,
    isAuthenticated,
    login,
    register,
    loginWithPhone,
    loginWithWechat,
    sendSmsCode,
    getQrCode,
    checkQrCodeStatus,
    mockScanQrCode,
    mockConfirmQrCode,
    completeLogin,
    logout,
    updateProfile,
  };
});
