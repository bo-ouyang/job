from datetime import datetime, timezone
from typing import Awaitable, Callable, Dict, Optional, Tuple

from config import settings
from crud import job as crud_job
from common.databases.PostgresManager import db_manager
from schemas.v2.common import DataStatus
from schemas.v2.market import (
    DistributionItem,
    FilterOption,
    KpiItem,
    MarketDashboardQuery,
    MarketDashboardResponse,
    MarketFilters,
    NamedValue,
    SalarySummary,
    TalentStructure,
    TrendData,
)
from services.analysis_service import analysis_service


StatsLoader = Callable[[MarketDashboardQuery], Awaitable[Tuple[Dict, str]]]

MISSING_MARKET_DIMENSIONS = [
    "market.monthly_job_trend",
    "market.salary_percentiles",
    "market.normalized_skill_frequency",
    "market.city_competition",
    "market.talent_shortage_index",
    "market.source_coverage",
]


class MarketDashboardService:
    def __init__(
        self,
        stats_loader: Optional[StatsLoader] = None,
        now: Optional[Callable[[], datetime]] = None,
    ):
        self._stats_loader = stats_loader or self._load_stats
        self._now = now or (lambda: datetime.now(timezone.utc))

    @staticmethod
    def _numeric_code(value: Optional[str]) -> Optional[int]:
        if value is None or value == "":
            return None
        try:
            return int(value)
        except (TypeError, ValueError):
            return None

    async def _load_stats(self, query: MarketDashboardQuery) -> Tuple[Dict, str]:
        city_code = self._numeric_code(query.city)
        industry_code = self._numeric_code(query.industry)
        if settings.ES_ENABLED:
            try:
                data = await analysis_service.get_faceted_job_stats(
                    location=city_code,
                    experience=query.experience,
                    industry=industry_code,
                )
                return data, "elasticsearch"
            except Exception:
                pass

        async with db_manager.async_session() as session:
            data = await crud_job.get_statistics_from_db(
                session,
                location=city_code,
                experience=query.experience,
                education=query.education,
                industry=industry_code,
            )
        return data, "postgresql"

    @staticmethod
    def _distribution(items: list) -> list[DistributionItem]:
        total = sum(max(0, float(item.get("value") or 0)) for item in items)
        if total <= 0:
            return []
        peak = max(float(item.get("value") or 0) for item in items)
        return [
            DistributionItem(
                label=str(item.get("name") or "未知"),
                value=round(float(item.get("value") or 0) / total * 100, 1),
                featured=float(item.get("value") or 0) == peak,
            )
            for item in items
        ]

    @staticmethod
    def _named_values(items: list) -> list[NamedValue]:
        return [
            NamedValue(name=str(item.get("name") or "未知"), value=float(item.get("value") or 0))
            for item in items
            if item.get("name")
        ]

    async def get_dashboard(self, query: MarketDashboardQuery) -> MarketDashboardResponse:
        raw, source = await self._stats_loader(query)
        total_jobs = int(raw.get("total_jobs") or 0)
        industries = self._named_values(raw.get("industries") or [])
        skills = self._named_values(raw.get("skills") or [])
        updated_at = self._now()

        return MarketDashboardResponse(
            updated_at=updated_at.isoformat(),
            data_status=DataStatus(
                source=source,
                degraded=source != "elasticsearch",
                updated_at=updated_at,
                available_dimensions=[
                    "market.total_jobs",
                    "market.salary_distribution",
                    "market.skill_frequency_raw",
                    "market.industry_distribution",
                ],
                missing_dimensions=MISSING_MARKET_DIMENSIONS,
            ),
            filters=MarketFilters(
                ranges=[FilterOption(label="近 12 个月", value="12m"), FilterOption(label="近 6 个月", value="6m"), FilterOption(label="近 30 天", value="30d")],
                cities=[FilterOption(label="全国", value="")],
                industries=[FilterOption(label="全部行业", value="")],
                educations=[FilterOption(label="不限学历", value=""), FilterOption(label="本科", value="本科"), FilterOption(label="硕士及以上", value="硕士")],
                experiences=[FilterOption(label="不限经验", value=""), FilterOption(label="应届 / 在校", value="应届生"), FilterOption(label="1–3 年", value="1-3年")],
            ),
            kpis=[
                KpiItem(label="在招岗位", value=total_jobs, note="当前有效样本", icon="▦", tone="blue"),
                KpiItem(label="全国月薪中位数", value=None, note="等待薪资快照", icon="¥", tone="mint"),
                KpiItem(label="热门行业", value=industries[0].name if industries else None, note="按岗位样本量", icon="↗", tone="violet"),
                KpiItem(label="技能需求热点", value=skills[0].name if skills else None, note="未标准化频次", icon="⌁", tone="orange"),
            ],
            trend=TrendData(),
            skills=skills,
            salary_distribution=self._distribution(raw.get("salary") or []),
            salary_summary=SalarySummary(),
            talent_structure=TalentStructure(),
        )


market_dashboard_service = MarketDashboardService()
