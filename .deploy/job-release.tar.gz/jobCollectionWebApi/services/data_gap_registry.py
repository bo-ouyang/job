from dataclasses import asdict, dataclass
from typing import Dict, List, Optional


@dataclass(frozen=True)
class DataGap:
    key: str
    module: str
    description: str
    required_fields: List[str]
    source_fields: List[str]
    refresh_frequency: str
    priority: str
    owner: str = "crawler"
    status: str = "missing"

    def to_dict(self) -> dict:
        return asdict(self)


_GAPS = (
    DataGap(
        key="market.monthly_job_trend",
        module="market",
        description="按自然月、城市和行业统计有效岗位发布量及同比/环比。",
        required_fields=["snapshot_month", "city_code", "industry_code", "active_job_count"],
        source_fields=["jobs.publish_date", "jobs.city_code", "jobs.industry_code", "jobs.is_active"],
        refresh_frequency="daily",
        priority="P0",
    ),
    DataGap(
        key="market.salary_percentiles",
        module="market",
        description="按城市、行业、学历和经验沉淀薪资 P25/P50/P75 历史快照。",
        required_fields=["snapshot_date", "dimension_key", "p25", "p50", "p75", "sample_size"],
        source_fields=["jobs.salary_min", "jobs.salary_max", "jobs.salary_unit"],
        refresh_frequency="daily",
        priority="P0",
    ),
    DataGap(
        key="market.normalized_skill_frequency",
        module="market",
        description="标准化技能别名并记录招聘文本中的需求频率与趋势。",
        required_fields=["skill_code", "canonical_name", "alias", "job_count", "snapshot_date"],
        source_fields=["jobs.tags", "jobs.ai_skills", "jobs.description", "jobs.requirements"],
        refresh_frequency="daily",
        priority="P0",
    ),
    DataGap(
        key="market.city_competition",
        module="market",
        description="城市岗位供给与候选人才数量形成的竞争度。",
        required_fields=["city_code", "job_count", "candidate_count", "competition_ratio"],
        source_fields=["jobs.city_code", "external_candidate_supply"],
        refresh_frequency="weekly",
        priority="P1",
    ),
    DataGap(
        key="market.talent_shortage_index",
        module="market",
        description="行业人才缺口和机会指数所需的供需指标。",
        required_fields=["industry_code", "demand_count", "supply_count", "shortage_index"],
        source_fields=["jobs.industry_code", "external_candidate_supply"],
        refresh_frequency="weekly",
        priority="P1",
    ),
    DataGap(
        key="market.source_coverage",
        module="quality",
        description="各招聘来源的采集覆盖率、失败率和数据新鲜度。",
        required_fields=["source_site", "expected_count", "collected_count", "latest_crawled_at"],
        source_fields=["jobs.source_site", "fetch_failures", "crawler_run_log"],
        refresh_frequency="hourly",
        priority="P1",
    ),
)

_BY_KEY: Dict[str, DataGap] = {gap.key: gap for gap in _GAPS}


def list_data_gaps(status: Optional[str] = None) -> List[DataGap]:
    if status is None:
        return list(_GAPS)
    return [gap for gap in _GAPS if gap.status == status]


def get_gap(key: str) -> DataGap:
    try:
        return _BY_KEY[key]
    except KeyError as exc:
        raise KeyError(f"Unknown data gap: {key}") from exc
